from tkinter import *
from tkinter import ttk
from tkinter import messagebox
import mysql.connector

conn = mysql.connector.connect(
    host="localhost",
    user="root",
    password="Kkodiarsu@1926",
    database="patient_db1",
    auth_plugin='caching_sha2_password'
)

def create_database():
    conn = mysql.connector.connect(
        host="localhost",
        user="root",
        password="Kkodiarsu@1926"
    )
    cursor = conn.cursor()
    cursor.execute("CREATE DATABASE IF NOT EXISTS patient_db1")
    conn.close()

def create_patients_table():
    conn = mysql.connector.connect(
        host="localhost",
        user="root",
        password="Kkodiarsu@1926",
        database="patient_db1"
    )
    cursor = conn.cursor()
    cursor.execute(''' 
        CREATE TABLE IF NOT EXISTS patients (
            patient_id VARCHAR(50) PRIMARY KEY,
            name VARCHAR(100) NOT NULL,
            age INT NOT NULL,
            address VARCHAR(255),
            mobile VARCHAR(15),
            disease VARCHAR(100)
        )
    ''')
    conn.close()

class Hospital:
    def __init__(self, root):
        self.root = root
        self.root.title("Hospital Management System")
        self.root.geometry("1200x600+100+100")
        self.root.configure(bg="#f0f8ff")  # Light background color

        # Title Label
        title_label = Label(self.root, text="Hospital Management System", font=("Arial", 24, "bold"), bg="#87ceeb", fg="white")
        title_label.pack(pady=20, fill=X)

        # Adding a frame for the input fields
        self.frame = Frame(self.root, bg="#e0ffff")
        self.frame.pack(pady=10, padx=20)

        # Input Fields
        labels = ["Patient ID:", "Name:", "Age:", "Address:", "Mobile No:", "Disease:"]
        self.entries = []

        for i, label in enumerate(labels):
            Label(self.frame, text=label, bg="#e0ffff", font=("Arial", 12, "bold")).grid(row=i, column=0, padx=10, pady=5)
            entry = Entry(self.frame, font=("Arial", 12, "bold"), bg="#ffffff")
            entry.grid(row=i, column=1)
            self.entries.append(entry)

        # Buttons
        button_frame = Frame(self.root, bg="#e0ffff")
        button_frame.pack(pady=10)

        Button(button_frame, text="Add Patient", command=self.add_patient, bg="#98fb98", font=("Arial", 12, "bold")).pack(side=LEFT, padx=5)
        Button(button_frame, text="Modify Patient", command=self.modify_patient, bg="#ffd700", font=("Arial", 12, "bold")).pack(side=LEFT, padx=5)
        Button(button_frame, text="Delete Patient", command=self.delete_patient, bg="#ff6347", font=("Arial", 12, "bold")).pack(side=LEFT, padx=5)

        # Treeview for displaying records
        self.columns = ("patient_id", "name", "age", "address", "mobile", "disease")
        self.tree = ttk.Treeview(self.root, columns=self.columns, show='headings')

        for col in self.columns:
            self.tree.heading(col, text=col.capitalize())
            self.tree.column(col, width=150)

        self.tree.pack(pady=10, padx=20)
        self.display_patients()

    def connect_database(self):
        return mysql.connector.connect(
            host="localhost",
            user="root",
            password="Kkodiarsu@1926",
            database="patient_db1"
        )

    def add_patient(self):
        patient_id = self.entries[0].get()
        name = self.entries[1].get()
        age = self.entries[2].get()
        address = self.entries[3].get()
        mobile = self.entries[4].get()
        disease = self.entries[5].get()

        if not (patient_id and name and age and address and mobile and disease):
            messagebox.showerror("Input Error", "Please fill all fields")
            return

        try:
            age = int(age)
        except ValueError:
            messagebox.showerror("Input Error", "Age must be an integer")
            return

        conn = self.connect_database()
        cursor = conn.cursor()
        cursor.execute(''' 
            INSERT INTO patients (patient_id, name, age, address, mobile, disease)
            VALUES (%s, %s, %s, %s, %s, %s)
        ''', (patient_id, name, age, address, mobile, disease))
        conn.commit()
        conn.close()

        messagebox.showinfo("Success", "Patient added successfully")
        self.display_patients()
        self.clear_fields()

    def modify_patient(self):
        patient_id = self.entries[0].get()
        name = self.entries[1].get()
        age = self.entries[2].get()
        address = self.entries[3].get()
        mobile = self.entries[4].get()
        disease = self.entries[5].get()

        if not (patient_id and name and age and address and mobile and disease):
            messagebox.showerror("Input Error", "Please fill all fields")
            return

        try:
            age = int(age)
        except ValueError:
            messagebox.showerror("Input Error", "Age must be an integer")
            return

        conn = self.connect_database()
        cursor = conn.cursor()
        cursor.execute(''' 
            UPDATE patients
            SET name = %s, age = %s, address = %s, mobile = %s, disease = %s
            WHERE patient_id = %s
        ''', (name, age, address, mobile, disease, patient_id))
        conn.commit()

        if cursor.rowcount == 0:
            messagebox.showerror("Update Error", "No record found with the given Patient ID")
        else:
            messagebox.showinfo("Success", "Record updated successfully")

        conn.close()
        self.display_patients()
        self.clear_fields()

    def delete_patient(self):
        patient_id = self.entries[0].get()

        if not patient_id:
            messagebox.showerror("Input Error", "Please provide a Patient ID to delete")
            return

        conn = self.connect_database()
        cursor = conn.cursor()
        cursor.execute('DELETE FROM patients WHERE patient_id = %s', (patient_id,))
        conn.commit()

        if cursor.rowcount == 0:
            messagebox.showerror("Delete Error", "No record found with the given Patient ID")
        else:
            messagebox.showinfo("Success", "Patient deleted successfully")

        conn.close()
        self.display_patients()
        self.clear_fields()

    def display_patients(self):
        for row in self.tree.get_children():
            self.tree.delete(row)

        conn = self.connect_database()
        cursor = conn.cursor()
        cursor.execute('SELECT * FROM patients')
        for row in cursor.fetchall():
            self.tree.insert('', 'end', values=row)
        conn.close()

    def clear_fields(self):
        for entry in self.entries:
            entry.delete(0, END)

if __name__ == "__main__":
    create_database()
    create_patients_table()
    root = Tk()
    ob = Hospital(root)
    root.mainloop()
